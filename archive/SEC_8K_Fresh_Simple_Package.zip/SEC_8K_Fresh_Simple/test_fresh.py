"""Independent synthetic fixtures only. No previous project/results and no LLM calls."""
from pathlib import Path
import tempfile,time,json,copy,contextlib,io,importlib.util
from unittest.mock import Mock,patch
spec=importlib.util.spec_from_file_location('fresh',Path(__file__).with_name('simple_sec8k.py'))
p=importlib.util.module_from_spec(spec);spec.loader.exec_module(p)
with tempfile.TemporaryDirectory() as t:
 root=Path(t);pipe=p.Pipeline(root/'new_run',time.monotonic()+1000)
 assert not list((root/'new_run/checkpoints').iterdir())
 try:p.Pipeline(root/'new_run',time.monotonic()+1000)
 except FileExistsError:pass
 else:raise AssertionError('Fresh root reused silently')
 event={'organization':'Aster Devices Inc.','product_name':'AeroGauge','product_description':'An indoor air-quality sensor.','evidence_ids':[100001],'needs_review':False}
 filing={'company_name':'Aster Devices Inc.','stock_name':'ASTX','accession':'SYNTHETIC-1','filing_time':'2025-01-02T12:00:00+00:00'}
 batch=[{'id':100001,'text':'Aster Devices Inc. introduced AeroGauge, an indoor air-quality sensor.','url':'synthetic','start':0,'end':80}]
 p.validate({'events':[event]},p.schema([100001]))
 try:p.validate({'events':[{**event,'product_description':'x'*180}]},p.schema([100001]))
 except Exception:pass
 else:raise AssertionError('180 characters accepted')
 assert pipe.check_event(event,batch,filing)[0]
 assert not pipe.check_event({**event,'product_name':'MadeUp'},batch,filing)[0]
 assert not pipe.check_event({**event,'needs_review':True},batch,filing)[0]
 try:p.validate({'events':[{**event,'evidence_ids':[999]}]},p.schema([100001]))
 except Exception:pass
 else:raise AssertionError('Nonexistent source ID accepted')
 print('PASS: fresh namespace, 179-character limit, evidence IDs, names and ambiguity handling.')
 # A no-keyword source is submitted in full instead of becoming an automatic negative.
 doc={'url':'synthetic','text':'Ordinary narrative without retrieval signals. '*60,'text_sha256':'fixture'}
 batches,coverage=pipe.passages([doc])
 assert coverage[0]['mode']=='full-text fallback'
 assert coverage[0]['all_units']==coverage[0]['selected_units']
 assert ''.join(u['text'] for b in batches for u in b)==doc['text']
 # Long selected inputs must be flagged, not silently truncated to fit a request budget.
 try:pipe.passages([{'url':'synthetic','text':'A new product was introduced for testing. '*3000,'text_sha256':'fixture'}])
 except ValueError as exc:assert 'not silently truncated' in str(exc)
 else:raise AssertionError('Over-budget text silently accepted')
 print('PASS: no-hit fallback and explicit oversized-document handling.')
 # Prove frozen 100-file discovery is balanced and does not inspect product results.
 fake_map={str(i):{'ticker':ticker,'cik_str':i+1,'title':'Synthetic '+ticker} for i,ticker in enumerate(p.TICKERS)}
 def json_fixture(url):
  if url.endswith('company_tickers.json'):return fake_map
  cik=int(url.split('CIK')[1].split('.')[0]);accs=[f'{cik:010d}-25-{j:06d}' for j in range(1,7)]
  return {'name':'Synthetic Issuer','filings':{'recent':{'accessionNumber':accs,'filingDate':['2025-06-01']*6,
    'form':['8-K']*6,'primaryDocument':['report.htm']*6,'acceptanceDateTime':['2025-06-01T12:00:00Z']*6},'files':[]}}
 pipe.sec_json=json_fixture;pipe.fetch=lambda url:b'<feed xmlns="http://www.w3.org/2005/Atom"></feed>'
 selected=pipe.discover();assert len(selected)==100 and len({f['accession'] for f in selected})==100
 assert p.pd.Series([f['stock_name'] for f in selected]).value_counts().max()==5
 print('PASS: 100 unique round-robin metadata-selected filings, five per company in the fixture.')
 # Positive, no-product, failed and ambiguous records remain distinguishable.
 good={'filing':filing,'status':'complete','events':[{'candidate_id':'positive','event':event,'grounded':True,'reason':'grounded','evidence':batch}],
       'seconds':1,'model_calls':1}
 negative={'filing':{**filing,'accession':'SYNTHETIC-2'},'status':'complete','events':[],'seconds':1,'model_calls':1}
 failed={'filing':{**filing,'accession':'SYNTHETIC-3'},'status':'error','events':[],'error':'Unreadable image','seconds':1,'model_calls':0}
 uncertain={'filing':{**filing,'accession':'SYNTHETIC-4'},'status':'complete','events':[{'candidate_id':'uncertain','event':event,'grounded':False,'reason':'ambiguous','evidence':batch}], 'seconds':1,'model_calls':1}
 fixture_manifest=[r['filing'] for r in [good,negative,failed,uncertain]]
 pipe.records=[good,negative,failed,uncertain];df,queue,summary=pipe.export(fixture_manifest)
 assert list(df.columns)==p.FIELDS and len(df)==1 and len(queue)==2
 assert summary['completed']==3 and not summary['all_processing_complete'] and not summary['submission_ready']
 assert summary['source_review_completed'] is False
 print('PASS: exact CSV, negative versus failed status, review queue and honest partial summary.')
 # The batch continues after one error and re-running THIS run does not duplicate completed records.
 pipe.records=[];lookup={r['filing']['accession']:r for r in [good,failed,negative]};calls=[]
 def process_fixture(f):calls.append(f['accession']);return lookup[f['accession']]
 pipe.process=process_fixture;manifest=[r['filing'] for r in [good,failed,negative]]
 with contextlib.redirect_stdout(io.StringIO()):pipe.run(manifest)
 assert len(calls)==3 and len(pipe.records)==3
 with contextlib.redirect_stdout(io.StringIO()):pipe.run(manifest)
 assert len(calls)==4 and len(pipe.records)==3
 pipe.deadline=time.monotonic()-1
 with contextlib.redirect_stdout(io.StringIO()):_,_,summary=pipe.run(manifest)
 assert len(calls)==4 and summary['deadline_reached']
 print('PASS: continuous processing, no duplicate current-run records, and budget stop without new work.')
 # Inference contract: one model request per batch, duplicate citations normalized, no reviewer request.
 fresh=p.Pipeline(root/'request_fixture',time.monotonic()+100)
 response=Mock();response.raise_for_status.return_value=None
 response.json.return_value={'done_reason':'stop','message':{'content':json.dumps({'events':[{**event,'evidence_ids':[100001,100001]}]})}}
 with patch.object(p.requests,'post',return_value=response) as post:
  out=fresh.ask(filing,batch)
  assert post.call_count==1 and out[0]['evidence_ids']==[100001]
  assert post.call_args.kwargs['json']['think'] is False
 print('PASS: one-pass structured model contract and duplicate-citation normalization.')
print('ALL OFFLINE CHECKS PASSED. No live model extraction or five-hour benchmark was performed.')
