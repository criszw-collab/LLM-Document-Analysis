# Fresh, simple SEC 8-K assignment notebook

Author: Crispen Chachengwa

## Start

1. Open `SEC_8K_Fresh_Simple_Colab.ipynb` in https://colab.research.google.com/.
2. Choose Runtime > Change runtime type > GPU (T4 if offered).
3. Run the cells in order and authorize Google Drive when asked.
4. No project ZIP, old notebook, old manifest, prior CSV, checkpoints or review decisions are required or loaded.

The notebook has 19 cells, comments and an assignment workflow. Every run receives a new ID and writes to `My Drive/SEC8K_FRESH_RUNS/<run ID>`. Your earlier project is not read or modified. Public model weights may already be installed, but no old inference results or financial data are imported.

## Runtime target

The automated run is designed to fit within five hours on a functioning Colab GPU:

- 4.5-hour session budget, including setup/discovery elapsed time.
- Session watchdog interrupts extraction at that budget.
- 110-second per-filing request-boundary budget.
- 60-second model-request timeout.
- At most three selected-text batches per filing.
- One extraction model call per batch; no separate teacher or reviewer model call.
- Continuous processing: individual errors/review items do not stop the next filing.

These are computational limits, not a guarantee that 100 filings will complete within five hours. GPU quotas, model downloads, SEC access, unreadable sources and document sizes can prevent completion. The notebook saves partial results and records incomplete files honestly. Slow blocking file/network operations may add overhead beyond a timer boundary. It has NOT been benchmarked on a completed 100-filing Colab GPU run. Do not report a measured sub-five-hour completion unless your actual run demonstrates it.

The first five real filings print an early runtime projection. Review results after the batch, not one candidate at a time.

## Fresh data and source scope

Candidate companies: AMSC, AZTA, CRNC, DAKT, DIOD, FEIM, IPGP, IRDM, KN, KOPN, MLAB, MTSI, NVTS, POWI, SMTC, SPSC, VREX, ALNT, CLFD and DGII. A new public SEC ticker-map check found all 20 candidate symbols. This does not establish that each has enough eligible 2025 filings; the notebook validates coverage during discovery.

The sample contains 100 unique 2025 Form 8-K filings selected in round-robin order, capped at 10 per company and frozen before product extraction. Zero-product filings are retained, not replaced with positive examples.

The course ticker JSON and Atom endpoints are used. BeautifulSoup parses XML/HTML; submissions JSON provides exact form types, acceptance timestamps, history and a logged fallback if Atom is unavailable. SEC requests are identified, paced and serial. Access blocks are respected.

To keep this assignment run practical, automatic extraction covers the primary 8-K and the first Exhibit 99.1. Other supplementary exhibits, such as additional presentations and social-media screenshots, are excluded and logged. Image-only text within required sources and oversized/unreadable documents are flagged for review rather than silently treated as negative. Scanned PDFs and image OCR are not implemented in this simple version.

Readable source text is divided into numbered passages. Announcement-related passages and neighbors are submitted; if no signal is found, readable text is used as a fallback. No text is silently cut off to meet a one-call quota: a document exceeding the configured batch budget is flagged. This selected-passage approach can miss unusual wording; disclose its limitations.

## LLM and validation

Python queries the key-free public Qwen model `qwen3:4b-instruct-2507-q4_K_M` through Ollama inside Colab. Actual GPU memory allocation is checked before processing.

One prompt performs ORGANIZATION/PRODUCT NER and event extraction together. It allows explicit new named introductions, new named versions, firm future availability and initial shipments. It excludes acquisition-only news, personnel changes, employee plans, sales growth and generic unnamed products. Product names alone do not establish new releases.

Python validates JSON, actual source IDs, product-name occurrence, organization grounding and description lengths of 1-179 characters. Repeated citations are deduplicated and identical product names within a filing are grouped. Evidence units and entity labels are saved. These checks do not establish every semantic claim, so rows remain provisional until source review. No synthetic rows are exported to the real dataset.

## Outputs

All new results are saved to Drive as processing proceeds:

- `exports/manifest.csv` and `manifest.json`
- `exports/products.csv` — exactly the five required columns
- `exports/products_pipe.txt` — pipe-separated display companion
- `exports/filing_log.csv` — completed, failed and timed-out files
- `exports/review_queue.csv` — uncertainty, validation and source problems
- `exports/evidence_audit.json`
- `exports/run_summary.json`
- `exports/Methodology_Report.md` and `.pdf`
- `checkpoints/` and `responses/`

Required CSV schema:

`company_name,stock_name,filing_time,new_product,product_description`

One hundred filings does not imply one hundred product rows. A filing may produce zero, one or several rows. Errors and unreadable filings do not count as completed negative findings.

The report is labelled DRAFT until all processing completes, source review is genuinely recorded and a real GitHub URL is supplied. Read product evidence, resolve the queue, recover failed documents and check negative results. Do not merely toggle the review flag to make the report say complete. Inspect the final PDF and keep it to 1-2 pages. Publish the code and include the real GitHub project URL in the report and at the top of the CV; the notebook does not claim publication or a CV edit has already occurred.

The final cell downloads a ZIP containing only this new run. Saving files does not depend on reaching that cell; per-filing checkpoints and exports are already in Drive. An abrupt session loss can require retrying the active filing. This simple notebook does not automatically import a prior session's results. Re-running the processing cell in the same live run retains its own completed records without duplicating them.

## Testing and status

`validation_results.txt` contains the actual offline checks: fresh-directory isolation, schema/evidence/length validation, no-hit fallback, explicit oversized-source handling, balanced 100-filing selection using synthetic metadata, exact CSV fields, error-versus-negative distinction, continuous processing, current-run deduplication, budget-stop behavior and one-call structured request behavior. A public ticker-map lookup was also performed independently of old project data.

No fresh real filing extraction was executed here and no five-hour GPU completion benchmark is claimed. The notebook performs that new run in your Colab session.

The standalone `simple_sec8k.py` provides the pipeline class. Optional local offline tests:

```bash
pip install requests beautifulsoup4 pandas pypdf jsonschema
python test_fresh.py
```

## Official references

- https://www.sec.gov/edgar/sec-api-documentation
- https://www.sec.gov/search-filings/edgar-search-assistance/accessing-edgar-data
- https://docs.ollama.com/linux
- https://docs.ollama.com/api/ps
- https://research.google.com/colaboratory/faq.html
